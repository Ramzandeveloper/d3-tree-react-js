import React from "react";
import Tree from "react-d3-tree";
import axios from "axios";
import defaultArray from './convertedArray'
// const lastNode = defaultArray?.subChannel

// const parentName = defaultArray.filter(item => item.channelName === "Indirect Sales Channel");
// // const subanotherChannal = parentName.map(item => item.channelName)
// const array = parentName.map(item => item.subChannel.map(item => {
//   return {
//     name : item.channelName
//   }
// }))
// const array = parentName.map(item => item.subChannel.map(item => {
//   return {
//     name : item.channelName
//   }
// }))
// const parentSubchannel = parentName.map(item => item.subChannel.map(item => {
//   return{
//     name : item.channelName,
//     children: array[0]
//   }
// }))
// const schema = {

// }
// console.log("subChannel", array)
// const schemaData = [
//   {
//     name: "SomeValue",
//     children: [
//       {
//         name:"someValue",
//       }
//     ]
//   }
// ]
// console.log("defaultVale", parentName)
// // const directSalesChannel = defaultArray.filter(item => item.channelName === "Indirect Sales Channel");
// // const directSalesChannelList = directSalesChannel[0]?.subChannel?.map(item => {
// //   return{
// //     name: item.channelName,
// //     children: directSalesChannel?.subChannel?.filter(item => item.channelName === name).subChannel.channelName

// //   }
// // })

//console.log("directSalesChannelList",directSalesChannelList)
const debugData = [
  {
    name :"SALAM DMS",
    children : defaultArray
  }
 
];
console.log("dataForRender", debugData)
const containerStyles = {
  width: "100%",
  height: "100vh"
};

const svgSquare = {
  shape: "rect",
  shapeProps: {
    width: 20,
    height: 20,
    x: -10,
    y: -10
  }
};
//console.log("headers", directSalesChannel)
export default class CenteredTree extends React.PureComponent {
  state = {
  };

  componentDidMount() {
    const dimensions = this.treeContainer.getBoundingClientRect();
    this.setState({
      translate: {
        x: dimensions.width / 10,
        y: dimensions.width / 3
      }
    });
   }
  render() {
    {console.log("defaultArray",defaultArray)}
    return (
      <div style={containerStyles} ref={(tc) => (this.treeContainer = tc)}>
        <Tree
          data={debugData}
          translate={this.state.translate}
          orientation={"vertical"}
          nodeSvgShape={svgSquare}
          circleRadius={5}
        />
      </div>
    );
  }
}
