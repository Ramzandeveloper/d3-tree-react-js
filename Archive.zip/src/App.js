import "./styles.css";
import Tree from "./Tree";

export default function App() {
  return (
    <div className="App">
      <h1>Evamp Saanga</h1>
      <Tree />
    </div>
  );
}
