import React,{useState, useEffect, useRef} from "react";
import Tree from "react-d3-tree";
import axios from "axios";
import defaultArray from './convertedArray';
import Box from '@mui/material/Box';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import './custom-tree.css';
export default function CenteredTree () {
  
  const [channel, setChannel] = useState('Retail');
  
  const channels = defaultArray.filter(item => item.name === channel )
// const styleValues = channels[0].children.map(item => item.dealerType);
// console.log("valyesrrrr....", channels[0].children.map(item => item.dealerType))
// function flatten(channels) {
//   return channels? channels[0].reduce((result, item) => [
//       ...result,
//       { name: item.name },
//       ...flatten(item.children)
//   ], []) : [];
// }
function flatten(defaultArray) {
  return defaultArray? defaultArray.reduce((result, item) => [
      ...result,
      { name: item.name, type: item.dealerType },
      
      ...flatten(item.children)
  ], []) : [];
}
const valueFtn = flatten(defaultArray)
console.log("some",valueFtn);
  const debugData = [
    {
      name :"SALAM DMS",
      children : channels
    }
   
  ];
  const containerStyles = {
    width: "100%",
    height: "100vh"
  };
  
  const svgSquare = {
    shape: "rect",
    shapeProps: {
      width: 20,
      height: 20,
      x: -10,
      y: -10
    }
  };
  const handleChange = (event) => {
    setChannel(event.target.value);
  };
  const [translate, setTranslate] = useState({
    x: 0,
    y: 0
  })
  const treeContainer = useRef(null)
  useEffect(() => {
    const dimensions = treeContainer.current.getBoundingClientRect();
    setTranslate({
        x: dimensions.width / 10,
        y: dimensions.width / 3
    })
  }, []);

  return (
    
    <div style={containerStyles} ref={treeContainer}>
       <Box sx={{ maxWidth: 120 }}>
      <FormControl fullWidth>
        <InputLabel id="demo-simple-select-label">Select Channel</InputLabel>
        <Select
          labelId="demo-simple-select-label"
          id="demo-simple-select"
          value={channel}
          label="Select Channel"
          onChange={handleChange}
        >
          
          {defaultArray.map(item => <MenuItem value={item.name}>{item.name}</MenuItem> )}
        </Select>
      </FormControl>
    </Box>
    {console.log("debugData", debugData)}
      <Tree
        data={debugData}
        translate={translate}
        orientation={"vertical"}
        nodeSvgShape={svgSquare}
        rootNodeClassName={"node__root"}
        branchNodeClassName={valueFtn.type === "sub_distributor" ? "node__branch_sub" : "node__branch"}  //
        leafNodeClassName="node__leaf"
        circleRadius={5}
      />
    </div>
  );
} 
// export default class CenteredTree extends React.PureComponent {
//   state = {
//   };

//   componentDidMount() {
//     const dimensions = this.treeContainer.getBoundingClientRect();
//     this.setState({
//       translate: {
//         x: dimensions.width / 10,
//         y: dimensions.width / 3
//       }
//     });
//    }
//   render() {
//     {console.log("defaultArray",defaultArray)}
//     return (
//       <div style={containerStyles} ref={(tc) => (this.treeContainer = tc)}>
//         <Tree
//           data={debugData}
//           translate={this.state.translate}
//           orientation={"vertical"}
//           nodeSvgShape={svgSquare}
//           circleRadius={5}
//         />
//       </div>
//     );
//   }
// }
